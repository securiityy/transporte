import sqlite3
from flask import (
    Flask,
    render_template,
    request,
    redirect,
)
import json
import os
import random

app = Flask(__name__)

########################################################################
#                 FORMULRIO CLIENTE / MOTORISTA                        #
########################################################################
# esse endpoint é o formulario do cliente que manda via rede ngrok
# ciar dois arquivos json,html, como proc , dados temporarios
#
@app.route("/formclient", methods=['GET'])
def user_get():
    return render_template('formclient.html') 

@app.route("/dataclient", methods=['POST'])
def data_client():
    mydict = {
        'tipo':request.form.to_dict()['tipo'],
        'solicitacao':request.form.to_dict()['solicitacao'],
        'data':request.form.to_dict()['data'],
        'centrodecusto':request.form.to_dict()['centrodecusto'],
        'solicitante':request.form.to_dict()['solicitante'],
        'descricao':request.form.to_dict()['descricao'],
        'empregados':request.form.to_dict()['empregados'],
        'motorista':'',
        'veiculo':'',
        'placa':'',
        'kminicial':'',
        'kmfinal':'',
        'kmrodado':'',
        'horainicio':'',
        'horafinal':'',
        'horatotal':'',
        #'statusmotorista':'off',
        'id':random.randint(1,99)
    }
    with open(f'./proc/{mydict['id']}','w') as file:
        json.dump(mydict, file, indent=4)

    with open(f'./index.html','r') as pagina:
        paginaweb = pagina.read()

    with open(f'./templates/prochtml/{mydict['id']}.html','w') as file:
        file.write(f"""{paginaweb}""")
    return redirect('/formclient') 

########################################################################
#         Retorna o formulario do produto para manipulaçao             #
########################################################################
# aqui vai manipular todo o formualrio e mandar para o banco de dados
# tambem vai apagar os registron de section no dir ./porc/
@app.route("/proc/<int:id_section>", methods=['GET'])
def data_proc_form(id_section):
    with open(f'./proc/{id_section}', 'r') as file:
        return render_template(f'prochtml/{id_section}.html', dados=json.load(file)) 


@app.route("/procdata/<int:id_section_data>", methods=['POST'])
def data_proc_manipulation(id_section_data):
    alll = request.form.to_dict()
    if 'salvar' in request.form.to_dict():
        if request.form.to_dict()['salvar'] == 'salvar':
            del alll['salvar']
            with open(f'./proc/{id_section_data}','w') as file:
                file.write('')
                json.dump({**alll}, file, indent=4)
            return redirect(f'/homesection') 

    elif request.form.to_dict()['salvarguardar'] == 'salvarguardar':
        print('oiooioioiiii', tuple(request.form.to_dict().values()))
        del alll['id']
        del alll['salvarguardar']
        #del alll['statusmotorista']
        with open(f'./proc/{id_section_data}','w') as file:
            file.write('')
            json.dump({**alll}, file, indent=4)

        conn = sqlite3.connect('empresadb')
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS services (
            tipo TEXT NOT NULL,
            solicitacao TEXT NOT NULL,
            data TEXT NOT NULL,
            centrodecusto TEXT NOT NULL,
            solicitante TEXT NOT NULL,
            descricao TEXT NOT NULL,
            empregados TEXT NOT NULL,
            motorista TEXT NOT NULL,
            veiculo TEXT NOT NULL,
            placa TEXT NOT NULL,
            kminicial TEXT NOT NULL,
            kmfinal TEXT NOT NULL,
            kmrodado TEXT NOT NULL,
            horainicio TEXT NOT NULL,
            horafinal TEXT NOT NULL,
            horatotal TEXT NOT NULL
            );
        ''')
        cursor.execute("""
            INSERT INTO services (
            tipo, solicitacao, data, centrodecusto, solicitante,
            descricao, empregados,motorista,veiculo,placa,kminicial,kmfinal,
            kmrodado,horainicio,horafinal,horatotal
            )
            VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            tuple(alll.values())
        )
        conn.commit()
        conn.close()
        os.remove(f'./proc/{id_section_data}')
        os.remove(f'./templates/prochtml/{id_section_data}.html')
        return redirect(f'/homesection') 


########################################################################
#            Home de todas as section para gerenciar manual            #
########################################################################
@app.route("/homesection", methods=['GET'])
def usalskdjereee_geeet():
    return render_template('homesection.html', file=os.listdir('./proc/')) 

