senha = 'MTI0Nzg3NTkyODQ4MzE2ODQzNw.G5-KMR.PCG2INXnozuBXDRBikB1gZbbyfD6rmW12Prk8M'
#import subprocess
#import signal
#import time
#import threading
#def execute():
#    # Execute o arquivo Python
#    process = subprocess.Popen(["python", "mainflask.py"])
#    # Aguarde um pouco, ou faça qualquer outra coisa
#    time.sleep(15)
#    # Mate o processo
#    os.kill(process.pid, signal.SIGTERM)
#    print('processo finalizado!!!')
#@client.event
#async def on_ready():
#    print(f'We have logged in as {client.user}')
#
#@client.event
#async def on_message(message):
#
#    if message.content.startswith('aa'):
#        #threading.Thread(target=execute).start()
#        await message.channel.send(Questionnaire())
#@bot.command()
#async def b(ctx):
#    embed = discord.Embed()
#    embed.add_field(name="LINK DA SESSAO", value="https//:oioi", inline=False)
#    embed.add_field(name="ID", value="83291038640510983756129", inline=False)
#    await ctx.send(embed=embed)

import discord
from discord import app_commands
import traceback
import json
import os

TEST_GUILD = discord.Object(1247537783971778600)



class MessageTypes():
    def sucess(self):
        myembed = discord.Embed(title='SUCESS :white_check_mark:', colour=discord.Colour.green())
        myembed.add_field(name='KM INICIAL', value=f'{self.kminicial.value}')
        myembed.add_field(name='KM FINAL', value=f'{self.kmfinal.value}')
        myembed.add_field(name='HORA INICIAL', value=f'{self.kmfinal.value}')
        myembed.add_field(name='HORA FINAL', value=f'{self.kmfinal.value}')
        myembed.add_field(name='ID', value=f'{self.kmfinal.value}')
        return myembed

    def failed(self):
        myembed = discord.Embed(title='FAILED :o2:', colour=discord.Colour.red())
        myembed.add_field(name='HORA FINAL', value=f'{self.kmfinal.value}')
        myembed.add_field(name='ID', value=f'{self.kmfinal.value}')
        return myembed







class MyClient(discord.Client):
    def __init__(self) -> None:
        intents = discord.Intents.default()
        super().__init__(intents=intents)
        self.tree = app_commands.CommandTree(self)

    async def on_ready(self):
        print(f'Logged in as {self.user} (ID: {self.user.id})')
        print('------')

    async def setup_hook(self) -> None:
        # Sync the application command with Discord.
        await self.tree.sync(guild=TEST_GUILD)


class Feedback(discord.ui.Modal, title='Feedback'):
    kminicial = discord.ui.TextInput(
        label='KM INICIAL:',
        placeholder='Your name here...',
    )
    kmfinal = discord.ui.TextInput(
        label='KM FINAL:',
        placeholder='Your name here...',
    )
    horainicio = discord.ui.TextInput(
        label='HORA INICIAL:',
        placeholder='Your name here...',
    )
    horafinal = discord.ui.TextInput(
        label='HORA FINAL:',
        placeholder='Your name here...',
    )
    idsection = discord.ui.TextInput(
        label='ID:',
        placeholder='Id section',
    )

    async def on_submit(self, interaction: discord.Interaction):
        existfile = self.idsection.value in os.listdir('./proc/')
        if existfile:
            with open(f'./proc/{self.idsection.value}','r') as file:
                casa = json.load(file)
                casa['kminicial'] = self.kminicial.value
                casa['kmfinal'] = self.kmfinal.value
                casa['kmrodado'] = '9999' 
                casa['horainicio'] = self.horainicio.value
                casa['horafinal'] = self.horafinal.value
                casa['horatotal'] = '9999' 

            with open(f'./proc/{self.idsection.value}','w') as file:
                file.write('')
                json.dump(casa,file,indent=4)

            await interaction.response.send_message(
                embed=MessageTypes.sucess(self)
            ) 
        else:
            await interaction.response.send_message(
                embed=MessageTypes.failed(self),
                ephemeral=True
            ) 


    async def on_error(self, interaction: discord.Interaction, error: Exception) -> None:
        await interaction.response.send_message('Oops! Something went wrong.', ephemeral=True)
        traceback.print_exception(type(error), error, error.__traceback__)


client = MyClient()


@client.tree.command(guild=TEST_GUILD, description="Submit feedback")
async def feedback(interaction: discord.Interaction):
    await interaction.response.send_modal(Feedback())

@client.tree.command(guild=TEST_GUILD, description="embedsection")
async def embedsection(interaction: discord.Interaction):
    embed = discord.Embed()
    embed.add_field(name='KM INICIAL', value='{self.kminicial.value}')
    embed.insert_field_at(1,name='KM INICIAL', value='{self.kminicial.value}')
    await interaction.response.send_message(embed=embed)






client.run(senha)
